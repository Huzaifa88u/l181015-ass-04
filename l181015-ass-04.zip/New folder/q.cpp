#include<fstream>
#include<filesystem>
#include<dirent.h>
#include<cstring>
#include<string>
#include<unistd.h>
#include<vector>
#include<iostream>
using namespace std;
//import os
//import json


class blockSize{
public:
    int blocksize;

    blockSize( int sixe){
        blocksize=sixe;
    }
};
class Key_value
{
    string key;
    string value;

    Key_value(string k, string v)
    {
        key=k;
        value=v;
    }
};
class VolContrlBlock
{
    vector<Key_value> VCB;

    VolContrlBlock()
    {

    }
    void add_(Key_value kv)
    {
        VCB.push_back(kv);
    }
};


class FAT_Table
{
public:
    string file_name;
    int file_size;
    int start_block_id;
    
    FAT_Table(string file,int file_sixe, int start_blokid)
    {
        file_name=file;
        file_size=file_sixe;
        start_block_id=start_blokid;
    }
};



string filename="vir_hard_drive.txt";
string rdirectry="/home/huzaifa/root";	



void mkdir_command(string dire)
{
    string path = std::filesystem::path();
    path += "/";
    path += dire;
    if (std::filesystem::exists(path)){
        cout<<"The directory is already present."<<endl;
    }
    else{
        std::filesystem::create_directories(path);
        cout<<"Directory has been created"<<endl;
    }
}
void rm_command(string dir)
{
    string path = std::filesystem::current_path();
    path += "/";
    path += dir;
    
    if (std::filesystem::exists(path))
    {
        std::filesystem::remove_all(path);
        cout<<"Directory removed.\n";
    }
    else
    {
        cout<<"Directory does not exists.\n";
    }
}

void cd_command(string dir)
{
    
    if (chdir("dir") != 0)  
    perror("failed"); 
  
    if (chdir("/tmp") != 0)  
    perror("failed"); 

    if (chdir("/error") != 0)  
  
    
    perror("failed");   
  
}
void import(){
     
    string before,after,path;
    path=rdirectry;
    cout<<"enter the souce of the file"<<endl;
    cin>>before;
    cout<<"enter the destination of the file: "<<endl;
    cin>>after;
    if (std::filesystem::exists(before)){
        string path=rdirectry;
        path+="/";
        path+=after;
        if(std::filesystem::exists(path)){
            std::filesystem::copy(before, path);
            cout<<"imported "<<endl;
        }
        else{
            std::filesystem::create_directories(path);
            std::filesystem::copy(before, path);
            cout<<"imported "<<endl;
        }
       
    }
}
void ls_command(string path)
{
    struct dirent *x;
    DIR *dire = opendir(path.c_str());
    while ((x = readdir(dire)) != NULL) {
        cout << x->d_name << endl;
    }
    cout<<endl;

    closedir(dire);
}
int main()
{
    //blockSize data_blocks[1000];
    int block_s=0;
    ifstream fin(filename);
    char file;
   cout<<"..........................................Start....................................."<<endl;
   if(fin.is_open())
    {
        string path;
        fin>>path;
        fin>>path;
        chdir(path.c_str());
        fin.close();
    }
    else
    {
        ofstream fout(filename);
        cout<<"Enter block size: \n";
        cin>>block_s; 
        fout<<block_s<<endl;
        cout<<"Enter root directory path: \n";
        fout<<rdirectry<<endl;
        if (std::filesystem::exists(rdirectry))
        {
            chdir(rdirectry.c_str());
        }
        else
        {
            std::filesystem::create_directories(rdirectry);
            chdir(rdirectry.c_str());
        }

        fout.close();
    }

    ls_command(std::filesystem::current_path());

    
    return 0;

}

